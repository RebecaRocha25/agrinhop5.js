let colheitadeira;
let itens = [];
let pontuacao = 0;

function setup() {
  createCanvas(600, 400);
  colheitadeira = createVector(width / 2, height - 50);
}

function draw() {
  background(200, 255, 200); // fundo que lembra o campo
  // Desenhar a colheitadeira
  fill(150);
  rectMode(CENTER);
  rect(colheitadeira.x, colheitadeira.y, 60, 20);
  
  // Controlar a colheitadeira com as setas
  if (keyIsDown(LEFT_ARROW)) {
    colheitadeira.x -= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    colheitadeira.x += 5;
  }
  
  // Garantir que ela não saia da tela
  colheitadeira.x = constrain(colheitadeira.x, 30, width - 30);
  
  // Criar itens aleatórios
  if (frameCount % 60 === 0) {
    let itemX = random(20, width - 20);
    itens.push({ x: itemX, y: 0, size: 20 });
  }
  
  // Mostrar e mover os itens
  for (let i = itens.length - 1; i >= 0; i--) {
    fill(255, 200, 0);
    ellipse(itens[i].x, itens[i].y, itens[i].size);
    itens[i].y += 3;
    
    // Verificar se o item foi coletado
    if (
      dist(itens[i].x, itens[i].y, colheitadeira.x, colheitadeira.y) < 20
    ) {
      pontuacao++;
      itens.splice(i, 1);
    } else if (itens[i].y > height) {
      // Remove o item se passar da tela
      itens.splice(i, 1);
    }
  }
  
  // Mostrar a pontuação
  fill(0);
  textSize(20);
  text("Pontuação: " + pontuacao, 10, 30);
}